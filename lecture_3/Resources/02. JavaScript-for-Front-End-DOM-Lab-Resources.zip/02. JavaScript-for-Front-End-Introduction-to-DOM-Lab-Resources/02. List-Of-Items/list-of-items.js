function addItem() {
    // TODO:
}