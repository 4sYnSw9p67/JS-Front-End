function createArticle() {
	
	//TODO...
}